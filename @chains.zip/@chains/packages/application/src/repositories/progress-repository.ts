import { IProgress } from '@chains/interfaces';
import { Progress } from '@chains/domain';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

export class ProgressRepository implements IProgress {
  constructor(private readonly progressModel: Model<Progress>) {}

  async getProgress(): Promise<Progress> {
    const progress = await this.progressModel.findOne().exec();
    return progress || new Progress('eosio', -1, -100);
  }

  async saveProgress(progress: Progress): Promise<void> {
    await this.progressModel.updateOne({}, progress, { upsert: true });
  }
}
