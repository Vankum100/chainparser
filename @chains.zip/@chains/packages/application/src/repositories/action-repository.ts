import { IAction } from '@chains/interfaces';
import { Action } from '@chains/domain';
import { Model } from 'mongoose';

export class ActionRepository implements IAction {
  constructor(private readonly actionModel: Model<Action>) {}

  async findByTrxId(trxId: string): Promise<Action | null> {
    return this.actionModel.findOne({ trx_id: trxId }).exec();
  }

  async save(action: Action): Promise<void> {
    const newAction = new this.actionModel(action);
    await newAction.save();
  }
}
