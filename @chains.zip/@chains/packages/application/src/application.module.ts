import { forwardRef, Module } from '@nestjs/common';
import { FetchActionsService } from './services';
import { ConfigModule } from '@chains/config';
import { DatabaseModule } from '@chains/database';

@Module({
  imports: [forwardRef(() => ConfigModule), forwardRef(() => DatabaseModule)],
  providers: [FetchActionsService],
})
export class ApplicationModule {}
