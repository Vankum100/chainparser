import { Injectable } from '@nestjs/common';
import axios from 'axios';
import { ConfigService } from '@nestjs/config';
import { IAction, IProgress } from '@chains/interfaces';
import { Action } from '@chains/domain';

@Injectable()
export class FetchActionsService {
  private readonly apiUrl: string;
  private readonly accountName: string;

  constructor(
    private readonly actionRepository: IAction,
    private readonly progressRepository: IProgress,
    private readonly configService: ConfigService,
  ) {
    this.apiUrl = this.configService.get<string>('eos.apiUrl') as string;
    this.accountName = this.configService.get<string>(
      'eos.accountName',
    ) as string;
  }

  async fetchAndSaveActions() {
    const progress = await this.progressRepository.getProgress();

    const response = await axios.post(this.apiUrl, {
      account_name: this.accountName,
      pos: progress.pos,
      offset: progress.offset,
    });

    const actions = response.data.actions;
    for (const action of actions) {
      const { trx_id, block_time, block_num } = action.action_trace;

      const existingAction = await this.actionRepository.findByTrxId(trx_id);
      if (!existingAction) {
        const newAction = new Action(trx_id, block_time, block_num);
        await this.actionRepository.save(newAction);
      }
    }

    progress.updateProgress(progress.pos - 100, progress.offset);
    await this.progressRepository.saveProgress(progress);
  }
}
