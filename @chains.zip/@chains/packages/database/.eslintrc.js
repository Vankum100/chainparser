module.exports = {
    extends: '../../.eslintrc.js',
    rules: {
        '@typescript-eslint/no-explicit-any': 'error', // Example of overriding a rule
    },
};
