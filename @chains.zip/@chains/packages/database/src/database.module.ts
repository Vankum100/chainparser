import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ActionSchema, ProgressSchema } from './schemas';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Action', schema: ActionSchema },
      { name: 'Progress', schema: ProgressSchema },
    ]),
  ],
  exports: [MongooseModule],
})
export class DatabaseModule {}
