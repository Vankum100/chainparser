import { Schema } from 'mongoose';

export const ProgressSchema = new Schema({
  account_name: { type: String },
  pos: { type: Number },
  offset: { type: Number },
});
