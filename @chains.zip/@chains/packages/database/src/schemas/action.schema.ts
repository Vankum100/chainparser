import { Schema } from 'mongoose';

export const ActionSchema = new Schema({
  trx_id: { type: String, unique: true },
  block_time: { type: String },
  block_num: { type: Number },
});
