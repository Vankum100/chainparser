import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DatabaseModule } from '@chains/database';

@Module({
  imports: [
    MongooseModule.forRoot(
      process.env.MONGO_URI || 'mongodb://localhost:27017/eos-actions',
    ),
    DatabaseModule,
  ],
  exports: [MongooseModule],
})
export class InfrastructureModule {}
