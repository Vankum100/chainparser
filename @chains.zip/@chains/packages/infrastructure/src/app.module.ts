import { Module } from '@nestjs/common';
import { ConfigModule } from '@chains/config';
import { ApplicationModule } from '@chains/application';
import { DatabaseModule } from '@chains/database';
import { InfrastructureModule } from '@chains/infrastructure';

@Module({
  imports: [
    ConfigModule,
    ApplicationModule,
    DatabaseModule,
    InfrastructureModule,
  ],
})
export class AppModule {}
