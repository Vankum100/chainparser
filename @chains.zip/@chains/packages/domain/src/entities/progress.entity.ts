export class Progress {
  constructor(
    public account_name: string,
    public pos: number,
    public offset: number,
  ) {}

  updateProgress(newPos: number, newOffset: number) {
    this.pos = newPos;
    this.offset = newOffset;
  }
}
