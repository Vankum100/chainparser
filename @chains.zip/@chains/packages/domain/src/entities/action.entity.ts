export class Action {
  constructor(
    public readonly trx_id: string,
    public readonly block_time: string,
    public readonly block_num: number,
  ) {}
}
