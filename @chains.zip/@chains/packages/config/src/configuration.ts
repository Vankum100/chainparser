export default () => ({
  eos: {
    accountName: 'eosio',
    apiUrl: 'https://eos.greymass.com/v1/history/get_actions',
    initialPos: process.env.EOS_INITIAL_POS || -1,
    initialOffset: process.env.EOS_INITIAL_OFFSET || -100,
  },
});
