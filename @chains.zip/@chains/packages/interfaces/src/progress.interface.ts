import { Progress } from '@chains/domain';

export interface IProgress {
  getProgress(): Promise<Progress>;
  saveProgress(progress: Progress): Promise<void>;
}
