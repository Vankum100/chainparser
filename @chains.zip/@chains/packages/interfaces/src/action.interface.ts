import { Action } from '@chains/domain';

export interface IAction {
  findByTrxId(trxId: string): Promise<Action | null>;
  save(action: Action): Promise<void>;
}
